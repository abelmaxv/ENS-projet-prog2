
int main() {
  int v;
  v = 0;
  return 0;
}

