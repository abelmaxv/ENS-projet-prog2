
int global;

int main() {
  int* v;
  global = 2;
  v = 0;
  return 0;
}

