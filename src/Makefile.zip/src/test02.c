
int main() {
  int* v;
  int u, z;
  v = 0;
  return 0;
}

